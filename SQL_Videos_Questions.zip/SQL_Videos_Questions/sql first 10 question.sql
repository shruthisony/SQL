DROP TABLE IF EXISTS movie;
CREATE TABLE movie ( id VARCHAR(10) NOT NULL, title VARCHAR(200) DEFAULT NULL, year INT DEFAULT NULL, date_published DATE DEFAULT null, duration INT, country VARCHAR(250), worlwide_gross_income VARCHAR(30), languages VARCHAR(200), production_company VARCHAR(200), PRIMARY KEY (id) );

DROP TABLE IF EXISTS genre;
CREATE TABLE genre ( movie_id VARCHAR(10), genre VARCHAR(20), PRIMARY KEY (movie_id, genre) );

DROP TABLE IF EXISTS director_mapping;
CREATE TABLE director_mapping
( movie_id VARCHAR(10), name_id VARCHAR(10), PRIMARY KEY (movie_id, name_id) );

DROP TABLE IF EXISTS role_mapping;
CREATE TABLE role_mapping ( movie_id VARCHAR(10) NOT NULL, name_id VARCHAR(10) NOT NULL, category VARCHAR(10), PRIMARY KEY (movie_id, name_id) );

DROP TABLE IF EXISTS names;
CREATE TABLE names ( id varchar(10) NOT NULL, name varchar(100) DEFAULT NULL, height int DEFAULT NULL, date_of_birth date DEFAULT null, known_for_movies varchar(100), PRIMARY KEY (id) );

DROP TABLE IF EXISTS ratings;
CREATE TABLE ratings ( movie_id VARCHAR(10) NOT NULL, avg_rating DECIMAL(3,1), total_votes INT, median_rating INT, PRIMARY KEY (movie_id) );


USE imdb;
SELECT * FROM genre;
SELECT * FROM movie;
SELECT * FROM names;
SELECT * FROM ratings;
SELECT * FROM role_mapping

Q1. Find the total number of rows in each table of the schema?
SELECT COUNT(*) AS No_of_row_director_mapping FROM director_mapping;

-- Total numner of rows = 3876

SELECT COUNT(*) AS No_of_row_genre FROM genre;

-- Total Nos of rows = 14662

SELECT COUNT(*) AS No_of_row_movie FROM movie;

-- Total nos of rows = 7997

SELECT COUNT(*) AS No_of_row_names FROM names;

-- Total nos of rows = 25735

SELECT COUNT(*) AS No_of_row_ratings FROM ratings;

-- Total nos of rows = 7997

SELECT COUNT(*) AS No_of_row_role_mapping FROM role_mapping;

-- Total nos of rows = 15615

Q2. Which columns in the movie table have null values?
SELECT * FROM movie;
SELECT Sum(CASE
WHEN id IS NULL THEN 1
ELSE 0
END) AS id_null_count,
Sum(CASE
WHEN title IS NULL THEN 1
ELSE 0
END) AS title_null_count,
Sum(CASE
WHEN year IS NULL THEN 1
ELSE 0
END) AS year_null_count,
Sum(CASE
WHEN date_published IS NULL THEN 1
ELSE 0
END) AS date_published_null_count,
Sum(CASE
WHEN duration IS NULL THEN 1
ELSE 0
END) AS duration_null_count,
Sum(CASE
WHEN country IS NULL THEN 1
ELSE 0
END) AS country_null_count,
Sum(CASE
WHEN worlwide_gross_income IS NULL THEN 1
ELSE 0
END) AS worlwide_gross_income_null_count,
Sum(CASE
WHEN languages IS NULL THEN 1
ELSE 0
END) AS languages_null_count,
Sum(CASE
WHEN production_company IS NULL THEN 1
ELSE 0
END) AS production_company_null_count
FROM movie;

Q.1 Now that you have imported the data sets, let’s explore some of the tables. To begin with, it is beneficial to know the shape of the tables and whether any column has null values.Further in this segment, you will take a look at 'movies' and 'genre' tables.

SELECT * FROM genre;

SELECT * FROM movie;

SELECT * FROM names;

SELECT * FROM ratings;

SELECT * FROM role_mapping;

Q1. Find the total number of rows in each table of the schema? 

SELECT COUNT(*) AS No_of_row_director_mapping FROM director_mapping;

-- Total nos of rows = 3876

SELECT COUNT(*) AS No_of_row_genre FROM genre;

-- Total Nos of rows = 14662

SELECT COUNT(*) AS No_of_row_movie FROM movie;

-- Total nos of rows = 7997

SELECT COUNT(*) AS No_of_row_names FROM names;

-- Total nos of rows = 25735

SELECT COUNT(*) AS No_of_row_ratings FROM ratings;

-- Total nos of rows = 7997

SELECT COUNT(*) AS No_of_row_role_mapping FROM role_mapping;

-- Total nos of rows = 15615

Q2. Which columns in the movie table have null values? 

SELECT * FROM movie; SELECT Sum(CASE WHEN id IS NULL THEN 1 ELSE 0 END) AS id_null_count, Sum(CASE WHEN title IS NULL THEN 1 ELSE 0 END) AS title_null_count, Sum(CASE WHEN year IS NULL THEN 1 ELSE 0 END) AS year_null_count, Sum(CASE WHEN date_published IS NULL THEN 1 ELSE 0 END) AS date_published_null_count, Sum(CASE WHEN duration IS NULL THEN 1 ELSE 0 END) AS duration_null_count, Sum(CASE WHEN country IS NULL THEN 1 ELSE 0 END) AS country_null_count, Sum(CASE WHEN worlwide_gross_income IS NULL THEN 1 ELSE 0 END) AS worlwide_gross_income_null_count, Sum(CASE WHEN languages IS NULL THEN 1 ELSE 0 END) AS languages_null_count, Sum(CASE WHEN production_company IS NULL THEN 1 ELSE 0 END) AS production_company_null_count FROM movie;

Q3. Find the total number of movies released each year? How does the trend look month wise?

SELECT year, COUNT(id) as number_of_movies FROM movie GROUP BY year;


Q4. How many movies were produced in the USA or India in the year 2019?? 

SELECT COUNT(id) AS Total_Movie_Count FROM movie WHERE year = '2019' AND (country LIKE '%USA%' OR country LIKE '%India%');

-- Q5. Find the unique list of the genres present in the data set? 

SELECT DISTINCT(genre) AS Unique_genres FROM genre;

Q6.Which genre had the highest number of movies produced overall? 

SELECT genre, COUNT(movie_id) AS Number_of_movies FROM genre g INNER JOIN movie m ON g.movie_id = m.id GROUP BY genre ORDER BY Number_of_movies DESC LIMIT 1;

- Q7. How many movies belong to only one genre? 

WITH movies_with_one_genre AS (SELECT movie_id FROM genre GROUP BY movie_id HAVING Count(DISTINCT genre) = 1) SELECT Count(*) AS movies_with_one_genre FROM movies_with_one_genre;

 Q8.What is the average duration of movies in each genre? 
 
 SELECT g.genre, ROUND(AVG(m.duration),2) AS avg_duration FROM genre AS g INNER JOIN movie AS m ON g.movie_id = m.id GROUP BY g.genre;
 
 Q9.What is the rank of the ‘thriller’ genre of movies among all the genres in terms of number of movies produced? -- (Hint: Use the Rank function)
 
 WITH thriller_genre_rank AS ( SELECT genre, COUNT(movie_id), DENSE_RANK() OVER(ORDER BY COUNT(movie_id) DESC) genre_rank FROM genre GROUP BY genre ) SELECT * FROM thriller_genre_rank WHERE genre="Thriller";
 
 Q10. Find the minimum and maximum values in each column of the ratings table except the movie_id column?
 
 
 SELECT MIN(avg_rating) AS min_avg_rating, MAX(avg_rating) AS max_avg_rating, MIN(total_votes) as min_total_votes, MAX(total_votes) AS max_total_votes, MIN(median_rating) AS min_median_rating, MAX(median_rating) AS max_median_rating FROM ratings;